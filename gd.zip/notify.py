import requests
import json

def notify(msg):
    serverToken = 'AIzaSyDNmfAYnsmJDn6Bb0QIIzMvfciEume8oWY'
    deviceToken = 'dMUqCurCzTM:APA91bE52CslCknD9fQuLTfGNBY7du-quwg_3g4_eEuZSA_bIbnXtDkIFiSnp9MeG3zS2nzoN_5GBszCmBhqHCtFow1J1ILq2jE5xpzBL8VNah7sjA_9PrbxCc5DjNJ4lfDuFK0aUNms'
    senderid = "notification-40514"

    headers = {
            'Content-Type': 'application/json',
            'Authorization': 'key=' + serverToken,
            'Sender':senderid
      }

    body = {
         'notification':
             {
                 'header': 'Elderly assistance',
                 'body': msg,
                 'location':'72.4345,12.234897',
                 'type':'map'
          },
          'priority': 'high',
          'to':deviceToken
        }

    response = requests.post("https://fcm.googleapis.com/fcm/send",headers = headers, data=json.dumps(body))
    print(response.status_code)

    print(response.json())

